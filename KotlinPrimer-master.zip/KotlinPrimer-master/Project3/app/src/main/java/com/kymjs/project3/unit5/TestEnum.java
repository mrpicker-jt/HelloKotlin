package com.kymjs.project3.unit5;

/**
 * Created by ZhangTao on 18/6/13.
 */
public enum TestEnum {
    A, B, C, D
}
