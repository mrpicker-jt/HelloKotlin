package com.kymjs.mvpandroid.p

import com.kymjs.mvpandroid.m.User

interface IPresenter {
    fun doLogin(): User
}
