package com.kymjs.mvpandroid.v

import com.kymjs.mvpandroid.p.IPresenter

interface IView {
    fun getLayoutID(): Int
}