package com.kymjs.mvpandroid.m

data class User(var id: Int, var name: String)