package com.kymjs.kotlinprimer;

/**
 * Created by ZhangTao on 18/6/21.
 */
public interface AInterface {
    void putNumber(int num);

    void putNumber(Integer num);
}