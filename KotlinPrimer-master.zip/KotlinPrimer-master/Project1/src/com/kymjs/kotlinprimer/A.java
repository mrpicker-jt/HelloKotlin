package com.kymjs.kotlinprimer;

/**
 * Created by ZhangTao on 18/6/21.
 */
public class A {

    public static String format(String string) {
        return string.isEmpty() ? null : string;
    }
}
