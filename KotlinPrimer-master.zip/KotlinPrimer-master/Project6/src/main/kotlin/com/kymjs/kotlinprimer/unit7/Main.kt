package com.kymjs.kotlinprimer.unit7

/**
 * Created by ZhangTao on 18/7/14.
 */

fun main(args: Array<String>) {
    "hello"
}