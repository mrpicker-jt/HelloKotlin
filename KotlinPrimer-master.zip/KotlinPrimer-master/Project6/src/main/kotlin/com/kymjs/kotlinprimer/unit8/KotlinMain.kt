package com.kymjs.kotlinprimer.unit8

/**
 * Created by ZhangTao on 18/7/14.
 */
fun main(args: Array<String>) {
}


fun print(msg: String) {

}

fun print2(msg: String?) {

}