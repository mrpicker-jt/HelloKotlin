package com.kymjs.kotlinprimer.unit5

import java.io.File

/**
 * Created by ZhangTao on 18/7/7.
 */

fun `1234`() {
    println("test1")
}

fun ` `() {
    println("test2")
}

fun `  `() {
    println("test3")
}

fun main(args: Array<String>) {
    val a: File = A("")

}


public typealias A = File